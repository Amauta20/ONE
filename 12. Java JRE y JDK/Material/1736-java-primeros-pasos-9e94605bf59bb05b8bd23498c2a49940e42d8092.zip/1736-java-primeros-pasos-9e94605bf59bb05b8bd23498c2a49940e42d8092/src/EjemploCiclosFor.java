
public class EjemploCiclosFor {

	public static void main(String[] args) {
		
		//   variable           condicion      ejecutar al FINAL
		for (int contador = 0; contador <=10 ; contador++) {
			System.out.println(contador);
		}
	}
}
